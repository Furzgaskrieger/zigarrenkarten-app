# Aktuelle app.py mit neuen Features
