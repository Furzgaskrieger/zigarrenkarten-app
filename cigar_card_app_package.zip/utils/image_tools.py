from PIL import Image, ImageDraw, ImageFont
import os

def create_card(data, output_path):
    width, height = 1200, 630
    background_color = (245, 235, 220)
    img = Image.new("RGB", (width, height), color=background_color)
    draw = ImageDraw.Draw(img)

    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    small_font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    font_header = ImageFont.truetype(font_path, 40)
    font_label = ImageFont.truetype(font_path, 24)
    font_text = ImageFont.truetype(small_font_path, 22)

    draw.text((30, 25), f"{data.get('marke', '')} – {data.get('sorte', '')}", fill="black", font=font_header)

    lines = [
        ("Format", data.get("format", "")),
        ("Ringmaß", data.get("ringmass", "")),
        ("Länge", f"{data.get('laenge', '')} mm"),
        ("Stärke", data.get("staerke", "")),
        ("Rauchdauer", f"{data.get('dauer', '')} Min."),
        ("Deckblatt", data.get("deckblatt", "")),
        ("Umblatt", data.get("umblatt", "")),
        ("Einlage", data.get("einlage", ""))
    ]

    y_offset = 100
    for label, text in lines:
        draw.text((30, y_offset), f"{label}:", font=font_label, fill=(80, 50, 20))
        draw.text((250, y_offset), text, font=font_text, fill="black")
        y_offset += 40

    draw.text((30, 450), "Charakter & Besonderheiten:", font=font_label, fill=(80, 50, 20))
    draw.multiline_text((30, 490), data.get("beschreibung", ""), font=font_text, fill="black", spacing=6)

    if "bildpfad" in data and os.path.exists(data["bildpfad"]):
        try:
            user_img = Image.open(data["bildpfad"]).convert("RGB")
            user_img.thumbnail((300, 300))
            img.paste(user_img, (850, 50))
        except Exception as e:
            print("Bild konnte nicht eingebunden werden:", e)

    img.save(output_path)
