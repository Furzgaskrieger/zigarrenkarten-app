# Zigarren-App auf Proxmox installieren

## Installation im LXC-Container

1. Container erstellen mit Debian/Ubuntu
2. Projekt in `/root` kopieren oder per `scp` hochladen

### Abhängigkeiten
```bash
apt update && apt install -y python3 python3-pip
pip3 install -r requirements.txt
```

### App starten
```bash
python3 app.py
```

Zugriff im Browser: `http://[Proxmox-IP]:5000`

---

## Optional: Gunicorn + Nginx Setup

```bash
pip3 install gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```

Nginx-Proxy einrichten für Port 80 → 8000 (nach Wunsch)

---

## GitHub Upload
1. Repo erstellen
2. `git init && git remote add origin ...`
3. `git add . && git commit -m "initial commit"`
4. `git push -u origin main`
