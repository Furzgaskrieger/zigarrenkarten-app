
from PIL import Image

def load_cigar_image(path):
    img = Image.open(path).convert("RGBA")
    return img.resize((260, 820), Image.Resampling.LANCZOS)
